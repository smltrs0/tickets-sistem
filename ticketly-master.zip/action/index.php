<?php 
	header("location: ../");
?>