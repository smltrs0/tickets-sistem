<?php 
	
	header("location: ../");

?>