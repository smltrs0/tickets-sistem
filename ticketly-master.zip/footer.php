            </div>
        </div>
  <footer style="background-color: #2A3F54;" ><!-- footer content -->
                    <div class="pull-right">
                        <span class="text-muted" > Copy del sitios </span>  
                    </div>
                    <div class="clearfix"></div>
                </footer><!-- /footer content -->
        <!-- jQuery -->
        <script src="js/jquery/dist/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="css/bootstrap/dist/js/bootstrap.min.js"></script>

        <!--Libreria de las estadisticas-->
 <script src="js/chart.js/Chart.min.js"></script>
        <!-- Custom Theme Scripts -->
        <script src="js/custom.min.js"></script>
  <!-- Demo scripts for this page-->
  <script src="js/demo/chart-bar-demo.js"></script>
    </body>
</html>